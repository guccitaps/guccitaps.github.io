= = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = =
||   ____  _      ____   _____ _  __  _   _   _   _   _____   ____  _      _         ||
||  |  _ \| |    / __ \ / ____| |/ / | | | \ | | | | |  __ \ / __ \| |    | |        ||
||  | |_) | |   | |  | | |    |   /  |_| |  \| | |_| | |__) | |  | | |    | |        ||
||  |  _ <| |   | |  | | |    |  <       |     |     |  _  /| |  | | |    | |        ||
||  | |_) | |___| |__| | |____|   \      | |\  |     | | \ \| |__| | |____| |____    ||
||  |____/|______\____/ \_____|_|\_\     |_| \_|     |_|  \_\\____/|______|______|   ||
||                                                                                   ||
= = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = =

Merci d'avoir installé Block'N'Roll !
Nous espérons que vous aimerez notre jeu.

Site Internet : https://guccitaps.github.io/index.html
Nous contacter : contact.blocknroll@gmail.com

= = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = =

Thank you for installing Block'N'Roll!
We hope you will have a great time playing our game.

Website: https://guccitaps.github.io/index.html
Contact us: contact.blocknroll@gmail.com

= = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = =